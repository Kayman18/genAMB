/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Charles Vestal */
/* AMB-1 on fm1-base: the app's unity build (compiled into fm1-base's, after the platform) and the glue between
 * fm1-base's contract (app.h) and AMB-1's parts: the project (project.c), the UI (ui.c) and the engine (dsp/amb.c,
 * its own -O2 unit). */
#include "project.c"
#include "ui.c"
#include "splash_genamb.h"

/* 240x240 indexed splash. The shared canvas is reused in 24-row strips, so the
 * artwork costs no extra RAM: 58 KB lives in XIP flash and only the existing
 * screen canvas is touched while the device is starting. */
void app_splash(void)
{
    uint32_t y, i;
    for (y = 0; y < 240u; y += 24u) {
        uint32_t h = 240u - y;
        if (h > 24u) h = 24u;
        cv_begin(240u, h, C_BLACK);
        for (i = 0; i < 240u * h; i++) {
            uint32_t k = GENAMB_SPLASH_IDX[y * 240u + i];
            cv_px[i] = swap16(GENAMB_SPLASH_PAL[k]);
        }
        cv_blit(0, y);
    }
}

/* the engine's MIDI out (clock, notes when MIDI out is on): to USB */
void en_midi_out(uint32_t st, uint32_t d1, uint32_t d2) { plat_midi_out(st >> 4 | st << 8 | d1 << 16 | d2 << 24); }

/* ---- the contract */
#if defined(PLAT_HOST) || defined(EN_HOST)
#define BOOT_STAGE(n) ((void)0)
#else
extern volatile uint32_t fm1_startup_stage;
#define BOOT_STAGE(n) (fm1_startup_stage = (n))
#endif
void app_init(void)
{
    BOOT_STAGE(10);
    en_init();
    BOOT_STAGE(20);
    project_load();                      /* defaults when nothing (or another format) is saved */
    en_evo_restore_boot(&proj.evo);
    en_fmevo_restore_boot(&proj.fm_evo);
    en_proteus_restore_boot(&proj.proteus);
    en_unitd_restore_boot(&proj.unitd);
    BOOT_STAGE(30);
    project_apply();
    BOOT_STAGE(40);
}
void app_render(int32_t *lr, uint32_t n, uint32_t gain_q12) { en_render(lr, n, gain_q12); }
void app_panic(void)
{
    en_play(0);
    en_panic();
}
void app_ui_init(void) { ui_init(); }
void app_frame(void) { ui_frame(); }
void app_input_only(void) { ui_input_only(); }
void app_say(const char *a, const char *b) { ui_say(a, b); }

#ifdef PLAT_HOST
#include "host.c"                        /* the host simulator's part: checks and commands */
#endif

#if defined(PLAT_HOST)
/* UI preview only: no hardware load is fabricated on the host. */
#include "perf.h"
uint32_t host_perf_dual=1;
static uint32_t host_perf_start;
void perf_read(perf_stats_t *s) {
    memset(s,0,sizeof *s); s->dual=host_perf_dual; s->status=2;
    s->seconds=(plat_ms()-host_perf_start)/1000u;
}
void perf_reset(void) { host_perf_start=plat_ms(); }
void perf_mode(int dual) { host_perf_dual=dual!=0; perf_reset(); }
#endif
