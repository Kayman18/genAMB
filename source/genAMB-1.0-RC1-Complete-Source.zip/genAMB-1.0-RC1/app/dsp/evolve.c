/* SPDX-License-Identifier: MPL-2.0
 * FM-1 Evolve: compact, clock-driven generative sequencing.
 * Independent implementation of random steps, probabilistic mutation and memory.
 * This file is included by amb.c; all writes occur on CPU0 in the audio engine.
 */
#define EVO_MAGIC 0x45564F31u
static volatile en_evo_bank_t evo_bank;
static volatile uint32_t evo_version;
volatile uint8_t en_evo_active, en_evo_pattern, en_evo_pos;
volatile uint8_t en_ring_seq_active_mode;
volatile uint8_t en_evo_trace[16];
static uint8_t evo_next, evo_wrapped;

static uint32_t evo_random(void)
{
    uint32_t x=evo_bank.rng;
    x^=x<<13; x^=x>>17; x^=x<<5;
    evo_bank.rng=x; return x;
}
static uint8_t evo_step_new(int density)
{
    uint8_t n=(uint8_t)(evo_random() & 127u);
    return n | (evo_random()%100u < (uint32_t)density ? 128u : 0u);
}
static void evo_publish(void)
{
    for(int i=0;i<16;i++) en_evo_trace[i]=evo_bank.step[en_evo_pattern][i];
}
static void evo_init(void)
{
    evo_version=0; evo_bank.magic=EVO_MAGIC; evo_bank.rng=0x9384B71Du;
    en_evo_active=en_evo_pattern=en_evo_pos=evo_next=evo_wrapped=0;
    en_ring_seq_active_mode=0;
    for(int p=0;p<16;p++)for(int i=0;i<16;i++) evo_bank.step[p][i]=evo_step_new(70);
    evo_publish();
}
void en_evo_snapshot(en_evo_bank_t *out)
{
    uint32_t before,after;
    do {
        before=evo_version; BARRIER();
        out->magic=evo_bank.magic;out->rng=evo_bank.rng;
        for(int p=0;p<16;p++)for(int i=0;i<16;i++)out->step[p][i]=evo_bank.step[p][i];
        BARRIER();after=evo_version;
    } while((before&1u)||before!=after);
}
void en_evo_restore_boot(const en_evo_bank_t *in)
{
    if(in->magic!=EVO_MAGIC || !in->rng)return;
    evo_bank.magic=in->magic;evo_bank.rng=in->rng;
    for(int p=0;p<16;p++)for(int i=0;i<16;i++)evo_bank.step[p][i]=in->step[p][i];
    evo_publish();
}
static void evo_select(void)
{
    int p=par[P_EPATTERN]-1;
    if(p<0||p>15)p=0;
    if(en_ring_seq_active_mode != par[P_RSEQMODE]) {
        /* Switch at the next bar; cancel pending strikes, preserve audible tails. */
        rings_wait_clear();
        en_ring_seq_active_mode=(uint8_t)par[P_RSEQMODE];
    }
    en_evo_active=(uint8_t)(en_ring_seq_active_mode==1);
    if(en_evo_pattern!=p) {
        en_evo_pattern=(uint8_t)p;evo_next=evo_wrapped=0;en_evo_pos=0;
    }
    evo_publish();
}
static void evo_randomize(void)
{
    int target=par[P_EPATTERN]-1; if(target<0||target>15)target=0;
    evo_version++; BARRIER();
    for(int i=0;i<16;i++)evo_bank.step[target][i]=evo_step_new(par[P_EDENSITY]);
    BARRIER();evo_version++;
    evo_publish();
}
static int evo_pitch(int value)
{
    /* Rank quantization: no notes outside the current harmony, including roots
     * near the octave boundary. Octave drift is applied after this mapping. */
    int base=60+par[P_ROOT]+12*par[P_BOCT], count=0, chosen=base;
    int span=12*par[P_ERANGE];
    for(int n=base;n<base+span;n++) {
        int ok=0, pc=n%12;
        if(par[P_EFOLLOW]) {for(int j=0;j<chord_nt;j++)if(pc==chord_pcs[j])ok=1;}
        else {for(int j=0;j<nsteps;j++)if(pc==(par[P_ROOT]+steps[j])%12)ok=1;}
        count+=ok;
    }
    if(!count)return base;
    int rank=value*count/128;
    for(int n=base;n<base+span;n++) {
        int ok=0,pc=n%12;
        if(par[P_EFOLLOW]) {for(int j=0;j<chord_nt;j++)if(pc==chord_pcs[j])ok=1;}
        else {for(int j=0;j<nsteps;j++)if(pc==(par[P_ROOT]+steps[j])%12)ok=1;}
        if(ok && rank--==0){chosen=n;break;}
    }
    return chosen;
}
static void evo_tick(void)
{
    int len=par[P_ELENGTH];
    if(evo_next>=len){evo_next=0;evo_wrapped=1;}
    if(evo_next==0 && evo_wrapped) {
        evo_version++;BARRIER();
        for(int i=0;i<len;i++)if(evo_random()%100u<(uint32_t)par[P_EMUTATE])
            evo_bank.step[en_evo_pattern][i]=evo_step_new(par[P_EDENSITY]);
        BARRIER();evo_version++;
        evo_wrapped=0;evo_publish();
    }
    en_evo_pos=evo_next;
    uint8_t step=evo_bank.step[en_evo_pattern][evo_next];
    if(step&128u) {
        int n=seq_note(evo_pitch(step&127u),par[P_RINGRANGE],par[P_RINGCHANCE],frand(),frand());
        /* Fold into MIDI bounds by octaves, preserving the harmonic pitch class. */
        while(n>127)n-=12;while(n<0)n+=12;
        ring_sequence_strike(n,0.8f,0);
    }
    if(++evo_next>=len){evo_next=0;evo_wrapped=1;}
}
